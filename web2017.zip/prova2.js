$(document).ready(main);



	function main () {
		var menuDesplegat = false;
		var subMenuDesplegat = false;

		$('.menuBtn').click(function(){

			if (menuDesplegat) {
				$('.menuBtn').html('<span class="icon_menu"</span>');
				$('nav').animate({
					opacity: '0'
				});
				$('nav').hide(500);
			} else {
				$('.menuBtn').html('<span class="icon_close"</span>');
				$('nav').show();
				$('nav').animate({
					opacity: '1'
				});
			}
			menuDesplegat = !menuDesplegat;
		});

		$('.subMenu').mouseenter(function(){
			$(this).children('.childrenGaleria').slideToggle();
		});
		$('.subMenu').mouseleave(function(){
			$(this).children('.childrenGaleria').slideToggle();
		});

		$(".btnDown").click(function(){
			$('html, body').animate({ scrollTop: $(".elementWrapper").offset().top-60}, 700);
		});

		$(".btnUp").click(function(){
			$('html, body').animate({ scrollTop: 0 }, 400);
		});

	}