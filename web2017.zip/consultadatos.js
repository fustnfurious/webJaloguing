	var last=0;
	(function worker() { // funcio que en servira per crear un bucle
		var arr_horas=""; // declarem els arrays a 0
		var arr_horas_nens=""; 
		var arr_personas="";
		var arr_personas_nens="";
		var frases=[
		"La última persona que entró en el túnel del terror desapareció. Nunca más se supo de ella. %s",
		"Ella está muy feliz de estar aquí conmigo. En el cementerio estaba sola. %s",
		"Llegas a casa, después de un largo y agotador día de trabajo. Te acercas al interruptor para apagar la luz, pero te das cuenta de que ya hay una mano ahí. %s",
		"Había una foto mía, mientras dormía, en mi teléfono. Yo no la tomé, y vivo solo. %s",
		"Mi hija no deja de llorar y gritar en medio de la noche. La he visitado en el cementerio para pedirle que se detenga, pero no lo hace. %s",
		"Mi esposa se despertó ayer en la noche para decirme que había un intruso en nuestra casa. Ella fue asesinada hace 2 años... por un intruso. %s",
		"Escucho la lluvia caer contra mi ventana, así que me acerco a ver. La ventana no está mojada, pero el vidrio está lleno de huellas. %s",
		'"Yo nunca... he matado a alguien". Todos los ojos se posaron en mi, mientras los cinco hombres levantaban sus vasos y los llevaban a sus labios para beber. %s',
		"En algunos juegos solo puedes recuperar salud cuando el personaje duerme, pero en ocasiones los monstruos te lo impiden. Ahora, ¿recuerdas la última vez que no pudiste dormir? %s",
		"Los trenes se retrasaron hoy. Parece que hay algo en los túneles. %s",
		"No hay nada como escuchar a un bebé reir. A no ser que sean las dos de la mañana y estés solo en casa. %s",
		"Si sientes un picor detrás de tus ojos, es recomedable ir al doctor. Probablemente ya se esté incubando mientras hablamos. %s",
		"Perdí mi oso de peluche la semana pasada. Él volvió a encontrarme. %s",
		"Dicen que si no has tenido ninguna pesadilla, es porque ésta aún no ha terminado. %s",
		"Encontré un cuerpo en el maletero de mi coche. Es extraño, porque recuerdo haber metido dos cuerpos ayer. %s",
		"Pensé que si no lo podía ver, esa cosa tampoco podía verme. Qué equivocada estaba. %s"
		//twitter.com/AfterMidnightSh
		];
		jQuery.ajax({ // fem la petició mitjançant post
			type: 'post',
			url: 'z_check_times.php',
			data: {
				//rownumber: rowNomber
			}, 
		// 	"horas"=>$result_h,
		// "personas"=>$result_p,
		// "personasn"=>$result_pn,
		// "actual"=>$actual,
		// "actual_nens"=>$actual_nens
			success: function(result) {
				$.each(result.horas, function( key, val ) {
					arr_horas += '<div>'+val[0]+' - '+val[1]+"</div>";
				});
				$.each(result.horasn, function( key, val ) {
					arr_horas_nens += '<div>'+val[0]+' - '+val[1]+"</div>";
				});
				$.each(result.personas, function( key, val ) {
					arr_personas += '<div>'+val[0]+' - '+val[1]+"</div>";
				});
				$.each(result.personasn, function( key, val ) {
					arr_personas_nens += '<div>'+val[0]+' - '+val[1]+"</div>";
				});
				$("#horas").html(arr_horas);
				$("#personas").html(arr_personas);
				$("#horasP").html(arr_horas_nens);
				$("#personasP").html(arr_personas_nens);
				if (last!=result.actual){
					var aleatorio = Math.round(Math.random()*(frases.length-1));
					$("#actual").html("<h2>Los espíritus nos comentan que...</h2><h3>"+frases[aleatorio].replace('%s', "<p class='ultim'>Último número adults:  "+result.actual+"</p><p class='ultim'>Último número petits valents:  "+result.actual_nens+"</p></h3>"));
				}
				if(result.alerta!="-"){
					$("#numeros").show();
					$("#numeros").html('<div class="numerosTornsDiv">'+result.alerta+'</div>');	
				}	else {
					$("#numeros").hide();
				}
				last=result.actual;
			}, error: function() {
				//alert("Y él voló y se estrelló acá por la pared, y se reventó toito");
			}, complete: function() {
				setTimeout(worker, 60000);
			}
		});
	})();