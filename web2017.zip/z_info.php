<?php
$DBServer = 'localhost';
$DBUser   = 'id1573624_jalo2017';
$DBPass   = 'jaloalpi';
$DBName   = 'id1573624_jaloguing2017';
include('z_JSON.php');
$json = new Services_JSON();
$conn = new mysqli($DBServer, $DBUser, $DBPass, $DBName);
if ($conn->connect_error) {
	trigger_error('Database connection failed: '  . $conn->connect_error, E_USER_ERROR);
}
$sql='SELECT minxfranja,persxfranja,entrades FROM config WHERE alerta="" ORDER BY time_update DESC';
$sql_alert='SELECT alerta FROM config WHERE alerta!="" ORDER BY time_update DESC';
$sql_actual='SELECT numero FROM entrada WHERE categoria="adults" ORDER BY time_update DESC';
$sql_actual_nens='SELECT numero FROM entrada WHERE categoria="nens" ORDER BY time_update DESC';
$rs=$conn->query($sql);
$rs_actual=$conn->query($sql_actual);
$rs_actual_nens=$conn->query($sql_actual_nens);
$rs_alert=$conn->query($sql_alert);
$arr = $rs->fetch_all(MYSQLI_ASSOC); 
$arr_actual = $rs_actual->fetch_all(MYSQLI_ASSOC); 
$arr_actual_nens = $rs_actual_nens->fetch_all(MYSQLI_ASSOC); 
$arr_alert = $rs_alert->fetch_all(MYSQLI_ASSOC); 
$MinutsxFranja=intval($arr[0]["minxfranja"]);
$personesxfranja=intval($arr[0]["persxfranja"]);
$actual=intval($arr_actual[0]["numero"]);
$actual_nens=intval($arr_actual_nens[0]["numero"]);
$alerta=$arr_alert[0]["alerta"];
$NumeroFranjes=(intval($arr[0]["entrades"])- $actual) / $personesxfranja;
date_default_timezone_set("Europe/Madrid");
?>