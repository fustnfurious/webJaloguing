$(document).ready(changeTitlePosition);
	function changeTitlePosition(){
		  $(window).scroll(function(){
		    if($(this).scrollTop()>=180){
		        $('.quiSomTitolContainer').css("position", "fixed");
		        $('.quiSomTitolContainer').css("margin-top", "0px");
		        $( ".quiSomTitol" ).animate({
				    height: "50px",
				    fontSize: "40px"
				  }, 300 );

		    } else {
		    	$('.quiSomTitolContainer').css("position", "absolute");
		        $('.quiSomTitolContainer').css("margin-top", "180px");
		        
		    }
		  });
		});