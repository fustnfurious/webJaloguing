$(document).ready(main);
		function main () {
			var fotoActual=0;
			document.addEventListener("keydown",keyPush);
			function keyPush(evt) {
			    switch(evt.keyCode) {
			        case 37:
			            passaEsquerra();
			            break;
			        case 39:
			            passaDreta();
			            break;
			    }
			}
			function passaDreta(){
					fotoDespres=fotoActual+1;
					if(fotoDespres>$(".mainGaleria > .foto").length){
						fotoDespres=1;
					}
					fotoActualString = fotoActual.toString();
					fotoDespresString = fotoDespres.toString();
					var imgF = $(".fotoDisplay").html().replace("mG("+fotoActualString, "mG("+fotoDespresString);
					$(".fotoDisplay").html(imgF);
					fotoActual = fotoDespres;
				}
			function passaEsquerra(){
				fotoDespres=fotoActual-1;
					if(fotoDespres<1){
						fotoDespres=$(".mainGaleria > .foto").length;
					}
					fotoActualString = fotoActual.toString();
					fotoDespresString = fotoDespres.toString();
					var imgF = $(".fotoDisplay").html().replace("mG("+fotoActualString, "mG("+fotoDespresString);
					$(".fotoDisplay").html(imgF);
					fotoActual = fotoDespres;
			}
			
				$("#rightBtn").click(passaDreta);
				$("#leftBtn").click(passaEsquerra);

				$("#closeBtn").click(function(){
					$(".fotoDisplayContainer").hide(500);
				});
				$(".foto").click(function(){
					fotoActual=parseInt($(this).attr('id'));
					$(".fotoDisplayContainer").show(500);
					var imgP = $(this).html().replace("fotoHover", "fotoHoverEnDisplay");
					var imgG = imgP.replace("P", "G");
					$(".fotoDisplay").html(imgG);
				});
				$("#leftBtn").click(function(){
					$(".fotoDisplay").html();
				});
			if($(window).width()>845){//no mobil
				$(".foto").mouseenter(function(){
					$(this).find(".fotoHover").css("display", "flex");
					$(this).find(".fotoHover").animate({
						opacity: '.8'
					}, 300);
					$(this).find(".fletxaDalt").delay(50).animate({
						left: '10px',
						bottom: '10px'
					}, 500);
					$(this).find(".fletxaBaix").delay(50).animate({
						right: '10px',
						top: '10px'
					}, 500);
				});
				$(".foto").mouseleave(function(){
					$(this).find(".fotoHover").animate({
						opacity: '.0'
					}, 300);
					$(this).find(".fletxaDalt").delay(50).animate({
						left: '-10px',
						bottom: '-10px'
					}, 500);
					$(this).find(".fletxaBaix").delay(50).animate({
						right: '-10px',
						top: '-10px'
					}, 500);
					wait(400);
					$(this).find(".fotoHover").css("display", "none");
				});
			}
		}