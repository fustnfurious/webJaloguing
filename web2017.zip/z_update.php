<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>INTRODUCIR NUMERO</title>
	<link rel="stylesheet" href="">
	<style>
		input[type=text], input[type=url], input[type=email], input[type=password], input[type=tel],input[type=number],input[type=submit] {
			-webkit-appearance: none; -moz-appearance: none;
			display: block;
			margin: 0;
			width: 50%; height: 100px;
			line-height: 25px; font-size: 50px;
			border: 1px solid #bbb;
		}
	</style>
</head>
<body>
<form action="z_update_bd.php?s=contador" method="post">
	<input type="number" name="nens" placeholder="NENS"><input type="number" name="adults" placeholder="ADULTS">
	<input type="submit"  value="Actualizar">
</form>
<BR><BR><BR><BR><BR><BR><BR><BR>
<form action="z_update_bd?s=sms" method="post">
	<input type="text" name="sms" placeholder="MISSATGE PÚBLIC">
	<input type="submit" value="PUBLICAR">
</form>
</body>
</html>