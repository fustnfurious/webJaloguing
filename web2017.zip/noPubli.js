$(document).ready(deletePubli);
function deletePubli(){
$("body").children().last().css("display", "none");
}