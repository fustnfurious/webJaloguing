<meta http-equiv="refresh" content="3;url=http://jaloguing.com/z_update.php" />
<?php
include('z_info.php');
date_default_timezone_set("Europe/Madrid");
$created=time()+60*60;
if($_GET['s']=="contador"){
	if(!empty($_POST['nens'])){
		$nens=$_POST["nens"];
		$sqls="INSERT INTO entrada (time_update,numero,categoria) VALUES ('$created','$nens','nens')";
		if($conn->query($sqls) === false) {
			trigger_error('Problema en base de datos, vuelva a insertar los valores (<a href="http://jaloguing.com/z_update.php">AQUI</a> ) : ' . $sqls . ' Error: ' . $conn->error, E_USER_ERROR);
		} else {
			$last_inserted_id = $conn->insert_id;
			$affected_rows = $conn->affected_rows;
			echo "true ".$created." -- ".$_POST['nens'];
		}
	}
	if(!empty($_POST['adults'])){
		$adults=$_POST["adults"];
		$created=$created+1;
		$sqls="INSERT INTO entrada (time_update,numero,categoria) VALUES ('$created','$adults','adults')";
		if($conn->query($sqls) === false) {
			trigger_error('Problema en base de datos, vuelva a insertar los valores (<a href="http://jaloguing.com/z_update.php">AQUI</a> ) : ' . $sqls . ' Error: ' . $conn->error, E_USER_ERROR);
		} else {
			$last_inserted_id = $conn->insert_id;
			$affected_rows = $conn->affected_rows;
			echo "true ".$created." -- ".$_POST['adults'];
		}
	}
}
if($_GET['s']=="sms"){
	if(!empty($_POST['sms'])){
		$sms=$_POST['sms'];
		$sqls="INSERT INTO config (time_update,alerta) VALUES ('$created','$sms')";
		if($conn->query($sqls) === false) {
			trigger_error('Problema en base de datos, vuelva a insertar los valores (<a href="http://jaloguing.com/z_update.php">AQUI</a> ) : ' . $sqls . ' Error: ' . $conn->error, E_USER_ERROR);
		} else {
			$last_inserted_id = $conn->insert_id;
			$affected_rows = $conn->affected_rows;
			echo "true".$created.$_POST['sms'];
		}	
	}
}
if($_GET['s']=="admin"){
	$persones=$_GET["persones"];
	$entrades=$_GET["entrades"];
	$sqls="INSERT INTO config (time_update,minxfranja,persxfranja,entrades) VALUES ('$created','15','$persones','$entrades')";
	if($conn->query($sqls) === false) {
		trigger_error('Problema en base de datos, vuelva a insertar los valores (<a href="http://jaloguing.com/z_update.php">AQUI</a> ) : ' . $sqls . ' Error: ' . $conn->error, E_USER_ERROR);
	} else {
		$last_inserted_id = $conn->insert_id;
		$affected_rows = $conn->affected_rows;
		echo "true".$created.$_POST['persones'].$_POST['entrades'];
	}
}
?>