<?php
include("z_info.php");
$inicial_hores=time();
$inicial_hores_nens=time();
if ($inicial_hores<(1509480000-60*60)){
	$inicial_hores=(1509480000-60*60);
}
if ($inicial_hores_nens<(1509472800-60*60)){
	$inicial_hores_nens=(1509472800-60*60);
}
 // establim el temps inicial consultant la hora en milisegons al servidor desde el gener de 1970 (epoca Unix)
$inicial_persones=$actual;
$inicial_persones_nens=$actual_nens;
 //establim el la posicio actual de les persones consultant a la bbdd el últim input del administrador
$result_h=Array(); // dec(sslarem Arrays per guardar la generació de hores y persones
$result_hn=Array();
$result_pn=Array();
$result_p=Array();
for ($i = 0; $i < $NumeroFranjes; $i++) {
	$final_hores=$inicial_hores+($MinutsxFranja*60); // la hora inicial en segons + els minuts que volem de interval * 60 (per passar la variable que esta en minuts a segons)
	$final_hores_nens=$inicial_hores_nens+($MinutsxFranja*60); // la hora inicial en segons + els minuts que volem de interval * 60 (per passar la variable que esta en minuts a segons)
	$final_persones=$inicial_persones+$personesxfranja;
	$final_persones_nens=$inicial_persones_nens+$personesxfranja;
	$result_p[$i]=[$inicial_persones,$final_persones]; // creem un array amb la Key que li correspongui del for y les variables dels intervals de les persones
	$result_pn[$i]=[$inicial_persones_nens,$final_persones_nens];
	$result_h[$i]=[date('H:i',$inicial_hores+60),date('H:i',$final_hores)]; // creem un array amb la mateixa key del for y les variables pasades a format de hores i minuts amb la funcio date()
	$result_hn[$i]=[date('H:i',$inicial_hores_nens+60),date('H:i',$final_hores_nens)];
	$inicial_hores=$final_hores; // establim els nous valors per a que el for pugui continuar
	$inicial_persones=$final_persones;
	$inicial_persones_nens=$final_persones_nens;
}
$returnArray = Array( // creem un array de arrays
		"horas"=>$result_h,
		"horasn"=>$result_hn,
		"personas"=>$result_p,
		"personasn"=>$result_pn,
		"actual"=>$actual,
		"actual_nens"=>$actual_nens,
		"alerta"=>$alerta
	);
$myjson = $json->encode($returnArray); // amb una funcio que esta dins del archiu z_JSON.php donem format de JSON al array
echo $myjson; // el mostrem en pantalla (︶︹︺) 
?>